import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { motion } from "framer-motion";
import { ArrowRight, Globe, Cpu, Code2, Lock, Rocket, Zap, MessageCircle, CheckCircle2, ChevronRight } from "lucide-react";
import logoImage from "@assets/logo_robe_systems.png";

const queryClient = new QueryClient();

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.15 } }
};

const scaleIn = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.5, ease: "easeOut" } }
};

const gentleFadeIn = {
  hidden: { opacity: 0, y: 8 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
};

const gentleStagger = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.08 } }
};

const gentleScaleIn = {
  hidden: { opacity: 0, y: 6 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } }
};

function smoothScrollTo(targetId: string) {
  const el = document.querySelector(targetId);
  if (!el) return;
  const start = window.scrollY;
  const end = (el as HTMLElement).getBoundingClientRect().top + start - 80;
  const distance = end - start;
  const duration = 900;
  let startTime: number | null = null;

  function easeInOutQuart(t: number) {
    return t < 0.5 ? 8 * t * t * t * t : 1 - Math.pow(-2 * t + 2, 4) / 2;
  }

  function step(timestamp: number) {
    if (!startTime) startTime = timestamp;
    const elapsed = timestamp - startTime;
    const progress = Math.min(elapsed / duration, 1);
    window.scrollTo(0, start + distance * easeInOutQuart(progress));
    if (progress < 1) requestAnimationFrame(step);
  }

  requestAnimationFrame(step);
}

function Logo({ className = "" }: { className?: string }) {
  return (
    <img src={logoImage} alt="Robe Systems" className={className} />
  );
}

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="cursor-pointer" data-testid="logo-home">
          <Logo className="h-16 w-auto" />
        </button>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-white/60">
          <button onClick={() => smoothScrollTo("#servicos")} className="hover:text-white transition-colors cursor-pointer" data-testid="nav-services">Serviços</button>
          <button onClick={() => smoothScrollTo("#diferenciais")} className="hover:text-white transition-colors cursor-pointer" data-testid="nav-differentials">Diferenciais</button>
          <button onClick={() => smoothScrollTo("#contato")} className="px-5 py-2.5 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-all cursor-pointer" data-testid="nav-contact">
            Falar com especialista
          </button>
        </div>
        <button onClick={() => smoothScrollTo("#contato")} className="md:hidden px-4 py-2 rounded-full bg-white/5 border border-white/10 text-white text-sm hover:bg-white/10 transition-all cursor-pointer" data-testid="nav-mobile-contact">
          Contato
        </button>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center pt-20 overflow-hidden">
      {/* Ambient top glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_45%_at_50%_0%,rgba(255,255,255,0.07),transparent)] pointer-events-none" />
      {/* Soft left orb */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_40%_40%_at_20%_60%,rgba(180,180,220,0.04),transparent)] pointer-events-none" />
      {/* Soft right orb */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_40%_40%_at_80%_55%,rgba(180,200,220,0.04),transparent)] pointer-events-none" />
      {/* Center floor glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_30%_at_50%_100%,rgba(255,255,255,0.03),transparent)] pointer-events-none" />
      <div className="max-w-4xl mx-auto px-6 relative z-10 w-full text-center">
        <motion.div initial="hidden" animate="visible" variants={staggerContainer}>
          <motion.h1 variants={fadeIn} className="text-5xl md:text-7xl lg:text-[88px] font-bold leading-[1.08] tracking-[-0.02em] mb-7 text-white">
            <motion.span
              className="inline-block origin-center"
              initial={{ scale: 1, color: "rgba(255,255,255,1)" }}
              animate={{ scale: 0.82, color: "rgba(255,255,255,0.3)" }}
              transition={{ delay: 1.4, duration: 1.2, ease: "easeInOut" }}
            >
              Tecnologia que
            </motion.span>
            <br />
            <motion.span
              className="inline-block origin-center"
              initial={{ scale: 1, color: "rgba(255,255,255,0.2)" }}
              animate={{ scale: 1.06, color: "rgba(255,255,255,1)" }}
              transition={{ delay: 1.4, duration: 1.2, ease: "easeInOut" }}
              style={{ display: "inline-block" }}
            >
              transforma negócios
            </motion.span>
          </motion.h1>
          <motion.p variants={fadeIn} className="text-lg md:text-xl text-white/45 mb-10 max-w-xl mx-auto font-light leading-relaxed">
            Sistemas sob medida, automação inteligente e plataformas digitais para empresas que querem crescer de verdade.
          </motion.p>
          <motion.div variants={fadeIn} className="flex flex-col sm:flex-row gap-3 justify-center">
            <button onClick={() => smoothScrollTo("#contato")} className="inline-flex items-center justify-center gap-2 h-12 px-7 rounded-full bg-white text-black text-sm font-semibold hover:bg-zinc-100 transition-all cursor-pointer" data-testid="hero-cta-primary">
              Solicitar orçamento <ArrowRight className="w-4 h-4" />
            </button>
            <button onClick={() => smoothScrollTo("#servicos")} className="inline-flex items-center justify-center gap-2 h-12 px-7 rounded-full text-white/70 text-sm font-medium border border-white/10 hover:border-white/25 hover:text-white transition-all cursor-pointer" data-testid="hero-cta-secondary">
              Ver soluções
            </button>
          </motion.div>
        </motion.div>
      </div>
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="flex flex-col items-center gap-2"
        >
          <div className="w-px h-12 bg-gradient-to-b from-white/20 to-transparent" />
        </motion.div>
      </div>
    </section>
  );
}

const services = [
  {
    icon: Code2,
    title: "Sistemas Sob Medida",
    description: "Desenvolvemos plataformas e aplicações personalizadas, alinhadas à operação da sua empresa e prontas para escalar com o negócio.",
    features: ["Web Apps & APIs", "Integrações ERP/CRM", "Portais Empresariais"]
  },
  {
    icon: Cpu,
    title: "Automação Inteligente",
    description: "Eliminamos gargalos operacionais com fluxos automatizados, reduzindo custos e aumentando a produtividade da sua operação.",
    features: ["RPA e bots de processo", "Fluxos de aprovação", "Relatórios automáticos"]
  },
  {
    icon: Globe,
    title: "Plataformas Digitais",
    description: "Construímos produtos digitais completos — do conceito ao lançamento — com foco em experiência do usuário e resultados reais.",
    features: ["SaaS e Marketplaces", "E-commerce B2B/B2C", "Apps Mobile"]
  },
  {
    icon: Zap,
    title: "Integrações & APIs",
    description: "Conectamos sistemas legados com ferramentas modernas, criando um ecossistema digital coeso, eficiente e de fácil manutenção.",
    features: ["Webhooks & REST APIs", "ERPs & CRMs", "Pagamentos & Logística"]
  },
  {
    icon: Lock,
    title: "Segurança & Compliance",
    description: "Garantimos que os sistemas da sua empresa seguem as melhores práticas de segurança e conformidade com regulamentações como LGPD.",
    features: ["Auditoria de segurança", "LGPD & compliance", "Autenticação avançada"]
  },
  {
    icon: Rocket,
    title: "Consultoria Técnica",
    description: "Assessoramos sua empresa na escolha das melhores tecnologias e na estruturação de uma arquitetura digital sustentável e escalável.",
    features: ["Arquitetura de software", "Revisão de sistemas", "Planejamento técnico"]
  }
];

function Services() {
  return (
    <section id="servicos" className="py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={gentleStagger}
          className="mb-16"
        >
          <motion.p variants={gentleFadeIn} className="text-xs uppercase tracking-widest text-white/30 font-semibold mb-4">Serviços</motion.p>
          <motion.h2 variants={gentleFadeIn} className="text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight max-w-xl">
            Tudo que seu negócio precisa para crescer.
          </motion.h2>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={gentleStagger}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5"
        >
          {services.map((service, i) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={i}
                variants={gentleScaleIn}
                className="bg-black p-8 flex flex-col gap-5 group hover:bg-white/[0.02] transition-colors cursor-default"
                data-testid={`service-card-${i}`}
              >
                <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-white/50 group-hover:text-white/40 transition-colors duration-500" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white group-hover:text-white/40 transition-colors duration-500 mb-2">{service.title}</h3>
                  <p className="text-sm text-white/45 group-hover:text-white/90 transition-colors duration-500 leading-relaxed">{service.description}</p>
                </div>
                <ul className="flex flex-col gap-2 mt-auto">
                  {service.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-2 text-xs text-white/35 group-hover:text-white/70 transition-colors duration-500">
                      <CheckCircle2 className="w-3.5 h-3.5 text-white/20 group-hover:text-white/50 flex-shrink-0 transition-colors duration-500" />
                      {f}
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}

const differentials = [
  {
    number: "01",
    title: "Foco em resultado, não em código",
    description: "Não entregamos apenas software — entregamos soluções que resolvem problemas reais e geram valor mensurável para o negócio."
  },
  {
    number: "02",
    title: "Comprometimento do início ao fim",
    description: "A Robe Systems assume o projeto com responsabilidade total. Sem repasses, sem terceirizações ocultas — do briefing à entrega."
  },
  {
    number: "03",
    title: "Transparência e comunicação contínua",
    description: "A empresa acompanha cada etapa do projeto com visibilidade total. Sem surpresas, sem achismos, sem promessas vazias."
  },
  {
    number: "04",
    title: "Escalável por design",
    description: "Sistemas construídos pensando no futuro da sua operação. Arquiteturas que crescem com o negócio, sem reescrever tudo do zero."
  }
];

function Differentials() {
  return (
    <section id="diferenciais" className="py-32 px-6 bg-white/[0.015]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={gentleStagger}
          className="mb-16"
        >
          <motion.p variants={gentleFadeIn} className="text-xs uppercase tracking-widest text-white/30 font-semibold mb-4">Diferenciais</motion.p>
          <motion.h2 variants={gentleFadeIn} className="text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight max-w-2xl">
            Por que empresas escolhem a Robe Systems.
          </motion.h2>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={gentleStagger}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {differentials.map((d, i) => (
            <motion.div
              key={i}
              variants={gentleFadeIn}
              className="flex gap-6"
              data-testid={`differential-${i}`}
            >
              <span className="text-xs font-mono text-white/20 mt-1 w-6 flex-shrink-0">{d.number}</span>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">{d.title}</h3>
                <p className="text-sm text-white/45 leading-relaxed">{d.description}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}


function Contact() {
  return (
    <section id="contato" className="py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="max-w-3xl mx-auto text-center"
        >
          <motion.p variants={fadeIn} className="text-xs uppercase tracking-widest text-white/30 font-semibold mb-4">Contato</motion.p>
          <motion.h2 variants={fadeIn} className="text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight mb-6">
            Pronto para transformar<br />seu negócio?
          </motion.h2>
          <motion.p variants={fadeIn} className="text-lg text-white/45 leading-relaxed mb-10">
            Entre em contato e descubra como a Robe Systems pode impulsionar seus resultados.
          </motion.p>
          <motion.div variants={fadeIn} className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="https://wa.me/5511983012404"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 h-14 px-8 rounded-full bg-white text-black text-sm font-semibold hover:bg-zinc-100 transition-all"
              data-testid="contact-whatsapp"
            >
              <MessageCircle className="w-5 h-5" />
              Falar pelo WhatsApp
            </a>
            <a
              href="mailto:robesystems@gmail.com"
              className="inline-flex items-center gap-2 h-14 px-8 rounded-full text-white/70 text-sm font-medium border border-white/10 hover:border-white/25 hover:text-white transition-all"
              data-testid="contact-email"
            >
              Enviar e-mail <ChevronRight className="w-4 h-4" />
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/5 py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <Logo className="h-12 w-auto" />
        <p className="text-sm text-white/25">
          © {new Date().getFullYear()} Robe Systems. Todos os direitos reservados.
        </p>
        <div className="flex items-center gap-6 text-sm text-white/30">
          <button onClick={() => smoothScrollTo("#servicos")} className="hover:text-white/60 transition-colors cursor-pointer">Serviços</button>
          <button onClick={() => smoothScrollTo("#diferenciais")} className="hover:text-white/60 transition-colors cursor-pointer">Diferenciais</button>
          <button onClick={() => smoothScrollTo("#contato")} className="hover:text-white/60 transition-colors cursor-pointer">Contato</button>
        </div>
      </div>
    </footer>
  );
}

function Home() {
  return (
    <main className="bg-black min-h-screen">
      <Navbar />
      <Hero />
      <Services />
      <Differentials />
      <Contact />
      <Footer />
    </main>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
